package veterinariaproject;

import veterinariaproject.views.MainView;

public class App 
{
    public static void main(String[] args) 
    {
        MainView main = new MainView();
        main.setVisible(true);
    }    
}
