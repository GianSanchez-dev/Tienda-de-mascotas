package veterinariaproject.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.stream.IntStream;

public class Cliente implements Serializable
{
    private int codigo;
    private String apellido;
    private long cuenta;
    private String direccion;
    private long telefono;
    private ArrayList<Persona> personas;
    private ArrayList<Mascota> mascotas;
    
    public Cliente()
    {
        personas = new ArrayList<>();
        mascotas = new ArrayList<>();
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setCuenta(long cuenta) {
        this.cuenta = cuenta;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setTelefono(long telefono) {
        this.telefono = telefono;
    }

    public void setPersonas(ArrayList<Persona> personas) {
        this.personas = personas;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getApellido() {
        return apellido;
    }

    public long getCuenta() {
        return cuenta;
    }

    public String getDireccion() {
        return direccion;
    }

    public long getTelefono() {
        return telefono;
    }

    public ArrayList<Persona> getPersonas() {
        return personas;
    }
    
    public ArrayList<Mascota> getMascotas() {
        return mascotas;
    }
    
    public Persona buscarPersona(long cedula)
    {
        return personas.stream().filter(persona -> persona.getCedula() == cedula).findFirst().orElse(null);
    }
    
    public boolean existePersona(long cedula)
    {
        return buscarPersona(cedula) != null;
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(!(o instanceof Cliente))
        {
            return false;
        }
        Cliente c = (Cliente)o;
        return c.codigo == this.codigo;
    }
    
    @Override
    public int hashCode()
    {
        int valor;
        valor = personas.stream().flatMapToInt(p -> IntStream.of(p.hashCode())).sum();
        return valor % Integer.MAX_VALUE;
    }
}
