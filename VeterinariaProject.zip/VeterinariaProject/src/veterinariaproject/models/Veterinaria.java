package veterinariaproject.models;

import java.io.File;
import java.io.Serializable;
import java.util.HashMap;

public class Veterinaria implements Serializable
{

    public static void setVeterinaria(Veterinaria veterinaria) {
        Veterinaria.veterinaria = veterinaria;
    }
    private HashMap<Integer, Cliente> clientes;
    private HashMap<Long, Mascota> mascotas;
    private static Veterinaria veterinaria;
    public static File archivo;
    
    private Veterinaria()
    {
        clientes = new HashMap<>();
        mascotas = new HashMap<>();
    }

    public void setClientes(HashMap<Integer, Cliente> clientes) {
        this.clientes = clientes;
    }

    public void setMascotas(HashMap<Long, Mascota> mascotas) {
        this.mascotas = mascotas;
    }

    public HashMap<Integer, Cliente> getClientes() {
        return clientes;
    }

    public HashMap<Long, Mascota> getMascotas() {
        return mascotas;
    }
    
    public static Veterinaria getVeterinaria()
    {
        if(veterinaria == null)
        {
            veterinaria = new Veterinaria();
        }
        return veterinaria;
    }
}
