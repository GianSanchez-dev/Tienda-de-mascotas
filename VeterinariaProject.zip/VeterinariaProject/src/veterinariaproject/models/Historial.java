package veterinariaproject.models;

import java.io.Serializable;
import java.time.LocalDate;

public class Historial implements Serializable
{
    private LocalDate fecha;
    private String razon;
    private float pesoMedido;
    private String detalle;
    
    public Historial(LocalDate fecha, String razon, float pesoMedido, String detalle)
    {
        this.fecha = fecha;
        this.razon = razon;
        this.pesoMedido = pesoMedido;
        this.detalle = detalle;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public void setRazon(String razon) {
        this.razon = razon;
    }
    
    public void setPesoMedido(float pesoMedido){
        this.pesoMedido = pesoMedido;
    }
    
    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public String getRazon() {
        return razon;
    }
    
    public float getPesoMedido(){
        return pesoMedido;
    }
    
    public String getDetalle() {
        return detalle;
    }
}
