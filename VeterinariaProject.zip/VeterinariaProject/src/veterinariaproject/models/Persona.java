package veterinariaproject.models;

import java.io.Serializable;

public class Persona implements Serializable
{
    private String nombre;
    private long cedula;
    
    public Persona(String nombre, long cedula)
    {
        this.nombre = nombre;
        this.cedula = cedula;
    }
    
    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }
    
    public void setCedula(long cedula)
    {
        this.cedula = cedula;
    }
    
    public String getNombre()
    {
        return nombre;
    }
    
    public long getCedula()
    {
        return cedula;
    }
    
    @Override
    public String toString()
    {
        return "Nombre: " + nombre + " - Cedula: " + cedula; 
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(!(o instanceof Persona)) return false;
        Persona p = (Persona)o;
        return p.cedula == this.cedula;
    }
    
    @Override
    public int hashCode()
    {
        return (int)(((this.cedula * Math.sqrt(5)) / 2) % Integer.MAX_VALUE);
    }
}
