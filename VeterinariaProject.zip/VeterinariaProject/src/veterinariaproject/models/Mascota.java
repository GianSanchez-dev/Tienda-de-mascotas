package veterinariaproject.models;

import java.awt.Color;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Mascota implements Serializable
{
    private long codigo;
    private String alias;
    private String especie;
    private String raza;
    private Color color;
    private LocalDate fechaNacimiento;
    private float pesoMedio;
    private float pesoActual;
    private ArrayList<Historial> historialMedico;
    private Cliente cliente;
    
    public Mascota()
    {
        historialMedico = new ArrayList<>();
    }
    
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public void setCodigo(long codigo) {
        this.codigo = codigo;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public void setPesoMedio(float pesoMedio) {
        this.pesoMedio = pesoMedio;
    }

    public void setPesoActual(float pesoActual) {
        this.pesoActual = pesoActual;
        if(historialMedico.isEmpty()){
            setPesoMedio(pesoActual);
            return;
        }
        int num = Math.min(10, historialMedico.size());
        float pesoTemp = pesoActual;
        for(int i = num-1; i > 0; i--){
            pesoTemp += historialMedico.get(i).getPesoMedido();
        }
        pesoTemp /= num;
        setPesoMedio(pesoTemp);
    }

    public long getCodigo() {
        return codigo;
    }
    
    public Cliente getCliente() {
        return cliente;
    }

    public String getAlias() {
        return alias;
    }

    public String getEspecie() {
        return especie;
    }

    public String getRaza() {
        return raza;
    }

    public Color getColor() {
        return color;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public float getPesoMedio() {
        return pesoMedio;
    }

    public float getPesoActual() {
        return pesoActual;
    }

    public ArrayList<Historial> getHistorialMedico() {
        return historialMedico;
    }

    public void setHistorialMedico(ArrayList<Historial> historialMedico) {
        this.historialMedico = historialMedico;
    }

    

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + (int) (this.codigo ^ (this.codigo >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Mascota other = (Mascota) obj;
        return this.codigo == other.codigo;
    }
}
