package veterinariaproject.controllers;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import veterinariaproject.models.Cliente;
import veterinariaproject.models.Mascota;
import veterinariaproject.models.Persona;
import veterinariaproject.models.Veterinaria;

public class Controller 
{
    public static Persona crearPersona(String nombre, long cedula)
    {
        Persona nuevaPersona = new Persona(nombre, cedula);
        boolean existePersona = Veterinaria.getVeterinaria().getClientes()
                                .entrySet().stream()
                                .flatMap(datosCliente -> datosCliente.getValue().getPersonas().stream())
                                .filter(persona -> persona.equals(nuevaPersona)).findAny().isPresent();
        if(existePersona) return null;
        return nuevaPersona;
    }
    
    public static boolean asociarPersonaACliente(Persona persona, int codigo)
    {
        Cliente cliente = Veterinaria.getVeterinaria().getClientes().get(codigo);
        
        if(cliente == null) return false;
        
        if(cliente.getPersonas().contains(persona)) return true;
        
        return cliente.getPersonas().add(persona);
    }
    
    public static Persona eliminarPersona(long cedula)
    {
        return Veterinaria.getVeterinaria().getClientes()
                                .entrySet().stream()
                                .flatMap(datosCliente -> datosCliente.getValue().getPersonas().stream())
                                .filter(persona -> persona.getCedula() == cedula).findFirst().orElse(null); 
    }
    
    public static Persona buscarPersona(long cedula){
        Optional<Persona> persona = Veterinaria.getVeterinaria().getClientes().entrySet().stream()
                                    .flatMap(datosCliente -> datosCliente.getValue().getPersonas().stream())
                                    .filter(p -> p.getCedula() == cedula).findFirst();
        return persona.orElse(null);
    }
    
    public static List<Cliente> listarClientesDePersona(long cedula)
    {
        return Veterinaria.getVeterinaria().getClientes()
                            .entrySet().stream()
                            .filter(datosCliente -> datosCliente.getValue().existePersona(cedula))
                            .map(datosCliente -> datosCliente.getValue())
                            .collect(Collectors.toList());
    }
    /************************* Controladores de cliente *********************************/
    
    public static Cliente buscarCliente(int codigo)
    {
        Cliente cliente = Veterinaria.getVeterinaria().getClientes().get(codigo);
        return cliente;
    }
    
    public static boolean existeCliente(int codigo)
    {
        return buscarCliente(codigo) != null;
    }
    
    public static boolean crearCliente(int codigo, String apellido, long cuenta, String direccion, long telefono)
    {
        if(existeCliente(codigo)){
            return false;
        }
        try{
            Cliente cliente = new Cliente();
            cliente.setCodigo(codigo);
            cliente.setApellido(apellido);
            cliente.setCuenta(cuenta);
            cliente.setDireccion(direccion);
            cliente.setTelefono(telefono);
            Veterinaria.getVeterinaria().getClientes().put(codigo, cliente);
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
        
        return true;
    }
    
    public static Cliente eliminarCliente(int codigo)
    {
        return Veterinaria.getVeterinaria().getClientes().remove(codigo);
    }
    /*********************************Controladores de mascotas************************/
    public static Mascota buscarMascota(long codigo)
    {
        return Veterinaria.getVeterinaria().getMascotas().get(codigo);
    }
    
    public static boolean existeMascota(long codigo)
    {
        return buscarMascota(codigo) != null;
    }
}
